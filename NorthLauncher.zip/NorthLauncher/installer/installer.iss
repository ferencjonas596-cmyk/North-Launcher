; Inno Setup script for North Launcher
; Build with: iscc installer.iss   (Inno Setup: https://jrsoftware.org/isinfo.php, free)
; Produces: installer/output/NorthLauncherSetup.exe

#define MyAppName "North Launcher"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Your Name"
#define MyAppExeName "NorthLauncher.exe"

; This assumes you've already built the project in Release mode, and that
; windeployqt has copied all required Qt DLLs next to the exe (CMake does
; this automatically - see CMakeLists.txt). Point BuildDir at that output folder.
#define BuildDir "..\build\Release"

[Setup]
AppId={{B6C1E9C2-8B2E-4B7A-9A0E-3C1D2E4F5A6B}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir=output
OutputBaseFilename=NorthLauncherSetup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=lowest
UninstallDisplayIcon={app}\{#MyAppExeName}

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional icons:"

[Files]
; Pull in everything windeployqt produced (exe + Qt DLLs + plugins) plus our own dependency DLLs.
Source: "{#BuildDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon
Name: "{group}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName} now"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
; Leave the user's ~/.mclauncher game data alone on uninstall - only remove the app files.
Type: filesandordirs; Name: "{app}"
