#include "MicrosoftAuth.h"
#include "../Utils/Http.h"
#include <nlohmann/json.hpp>
#include <thread>
#include <chrono>

using json = nlohmann::json;

namespace {
constexpr const char* kDeviceCodeUrl = "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode";
constexpr const char* kTokenUrl      = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token";
constexpr const char* kXblAuthUrl    = "https://user.auth.xboxlive.com/user/authenticate";
constexpr const char* kXstsAuthUrl   = "https://xsts.auth.xboxlive.com/xsts/authorize";
constexpr const char* kMcLoginUrl    = "https://api.minecraftservices.com/authentication/login_with_xbox";
constexpr const char* kMcEntitleUrl  = "https://api.minecraftservices.com/entitlements/mcstore";
constexpr const char* kMcProfileUrl  = "https://api.minecraftservices.com/minecraft/profile";
constexpr const char* kScope         = "XboxLive.signin offline_access";

std::string urlEncode(const std::string& s) {
    // Minimal encoder sufficient for our fixed set of form fields.
    std::string out;
    for (char c : s) {
        if (isalnum(static_cast<unsigned char>(c)) || c == '-' || c == '_' || c == '.' || c == '~') {
            out += c;
        } else if (c == ' ') {
            out += "%20";
        } else {
            char buf[4];
            snprintf(buf, sizeof(buf), "%%%02X", static_cast<unsigned char>(c));
            out += buf;
        }
    }
    return out;
}
}

MicrosoftAuth::MicrosoftAuth(std::string azureClientId) : clientId_(std::move(azureClientId)) {}

void MicrosoftAuth::cancel() { cancelRequested_ = true; }

std::optional<MicrosoftAuth::MsToken> MicrosoftAuth::deviceCodeFlow(const DeviceCodePrompt& onCodeReady) {
    cancelRequested_ = false;

    // Step 1: request a device code.
    std::string body = "client_id=" + urlEncode(clientId_) + "&scope=" + urlEncode(kScope);
    auto resp = Http::post(kDeviceCodeUrl, body, {"Content-Type: application/x-www-form-urlencoded"});
    if (!resp.ok()) return std::nullopt;

    json dc = json::parse(resp.body, nullptr, false);
    if (dc.is_discarded() || !dc.contains("device_code")) return std::nullopt;

    std::string deviceCode = dc["device_code"];
    std::string userCode = dc["user_code"];
    std::string verificationUri = dc.value("verification_uri", "https://microsoft.com/link");
    int interval = dc.value("interval", 5);
    int expiresIn = dc.value("expires_in", 900);

    if (onCodeReady) onCodeReady(userCode, verificationUri);

    // Step 2: poll the token endpoint until the user finishes logging in on their browser/phone.
    int elapsed = 0;
    while (elapsed < expiresIn) {
        if (cancelRequested_) return std::nullopt;

        std::this_thread::sleep_for(std::chrono::seconds(interval));
        elapsed += interval;

        std::string pollBody =
            "grant_type=urn:ietf:params:oauth:grant-type:device_code"
            "&client_id=" + urlEncode(clientId_) +
            "&device_code=" + urlEncode(deviceCode);

        auto pollResp = Http::post(kTokenUrl, pollBody, {"Content-Type: application/x-www-form-urlencoded"});
        json tokenJson = json::parse(pollResp.body, nullptr, false);
        if (tokenJson.is_discarded()) continue;

        if (tokenJson.contains("access_token")) {
            MsToken t;
            t.accessToken = tokenJson["access_token"];
            t.refreshToken = tokenJson.value("refresh_token", "");
            return t;
        }

        std::string error = tokenJson.value("error", "");
        if (error == "authorization_pending") continue;      // keep polling
        if (error == "slow_down") { interval += 5; continue; }
        // authorization_declined, expired_token, bad_verification_code, etc. -> give up.
        return std::nullopt;
    }
    return std::nullopt; // timed out
}

std::optional<MicrosoftAuth::MsToken> MicrosoftAuth::refreshMsToken(const std::string& refreshToken) {
    std::string body =
        "grant_type=refresh_token"
        "&client_id=" + urlEncode(clientId_) +
        "&refresh_token=" + urlEncode(refreshToken) +
        "&scope=" + urlEncode(kScope);

    auto resp = Http::post(kTokenUrl, body, {"Content-Type: application/x-www-form-urlencoded"});
    if (!resp.ok()) return std::nullopt;

    json tokenJson = json::parse(resp.body, nullptr, false);
    if (tokenJson.is_discarded() || !tokenJson.contains("access_token")) return std::nullopt;

    MsToken t;
    t.accessToken = tokenJson["access_token"];
    t.refreshToken = tokenJson.value("refresh_token", refreshToken);
    return t;
}

std::optional<MicrosoftAuth::Session> MicrosoftAuth::completeXboxChain(const MsToken& msToken) {
    // Step 3: Xbox Live user authentication.
    json xblBody = {
        {"Properties", {
            {"AuthMethod", "RPS"},
            {"SiteName", "user.auth.xboxlive.com"},
            {"RpsTicket", "d=" + msToken.accessToken}
        }},
        {"RelyingParty", "http://auth.xboxlive.com"},
        {"TokenType", "JWT"}
    };
    auto xblResp = Http::post(kXblAuthUrl, xblBody.dump(),
        {"Content-Type: application/json", "Accept: application/json"});
    if (!xblResp.ok()) return std::nullopt;

    json xbl = json::parse(xblResp.body, nullptr, false);
    if (xbl.is_discarded() || !xbl.contains("Token")) return std::nullopt;
    std::string xblToken = xbl["Token"];
    std::string userHash = xbl["DisplayClaims"]["xui"][0]["uhs"];

    // Step 4: XSTS authorization for the Minecraft relying party.
    json xstsBody = {
        {"Properties", {
            {"SandboxId", "RETAIL"},
            {"UserTokens", json::array({xblToken})}
        }},
        {"RelyingParty", "rp://api.minecraftservices.com/"},
        {"TokenType", "JWT"}
    };
    auto xstsResp = Http::post(kXstsAuthUrl, xstsBody.dump(),
        {"Content-Type: application/json", "Accept: application/json"});

    json xsts = json::parse(xstsResp.body, nullptr, false);
    if (xstsResp.status == 401 || xsts.is_discarded() || !xsts.contains("Token")) {
        // Common cause: account has no Xbox profile yet, or is under a child/family
        // restriction that blocks it - same limitation every third-party launcher hits.
        return std::nullopt;
    }
    std::string xstsToken = xsts["Token"];

    // Step 5: exchange for a Minecraft access token.
    json mcBody = {{"identityToken", "XBL3.0 x=" + userHash + ";" + xstsToken}};
    auto mcResp = Http::post(kMcLoginUrl, mcBody.dump(), {"Content-Type: application/json"});
    if (!mcResp.ok()) return std::nullopt;

    json mc = json::parse(mcResp.body, nullptr, false);
    if (mc.is_discarded() || !mc.contains("access_token")) return std::nullopt;
    std::string mcAccessToken = mc["access_token"];

    Session session;
    session.minecraftAccessToken = mcAccessToken;
    session.msRefreshToken = msToken.refreshToken;

    // Step 6: verify the account actually owns the game.
    auto entResp = Http::get(kMcEntitleUrl, {"Authorization: Bearer " + mcAccessToken});
    if (entResp.ok()) {
        json ent = json::parse(entResp.body, nullptr, false);
        session.ownsGame = !ent.is_discarded() && ent.contains("items") && !ent["items"].empty();
    }

    // Step 7: fetch the profile (username + UUID + skin).
    auto profResp = Http::get(kMcProfileUrl, {"Authorization: Bearer " + mcAccessToken});
    if (!profResp.ok()) return std::nullopt; // no profile = account has never set up Minecraft
    json prof = json::parse(profResp.body, nullptr, false);
    if (prof.is_discarded() || !prof.contains("id")) return std::nullopt;

    session.minecraftUuid = prof["id"];
    session.minecraftUsername = prof["name"];

    return session;
}

std::optional<MicrosoftAuth::Session> MicrosoftAuth::loginInteractive(const DeviceCodePrompt& onCodeReady) {
    auto msToken = deviceCodeFlow(onCodeReady);
    if (!msToken) return std::nullopt;
    return completeXboxChain(*msToken);
}

std::optional<MicrosoftAuth::Session> MicrosoftAuth::loginWithRefreshToken(const std::string& refreshToken) {
    auto msToken = refreshMsToken(refreshToken);
    if (!msToken) return std::nullopt;
    return completeXboxChain(*msToken);
}
