#pragma once
#include <string>
#include <functional>
#include <optional>

// Implements the full, official login chain required to run Minecraft: Java Edition
// with a real, purchased Microsoft account:
//
//   1. Microsoft OAuth2 Device Code flow      (login.microsoftonline.com)
//   2. Xbox Live user authentication          (user.auth.xboxlive.com)
//   3. Xbox Live XSTS authorization            (xsts.auth.xboxlive.com)
//   4. Minecraft Services login-with-Xbox      (api.minecraftservices.com)
//   5. Entitlement check + profile fetch       (api.minecraftservices.com)
//
// This is the same flow documented publicly for third-party launcher developers
// and requires the caller to supply their own Azure AD "Client ID" (see README).
// No credentials are ever handled directly by this app - the user authenticates
// on Microsoft's own login page in their browser.
class MicrosoftAuth {
public:
    struct Session {
        std::string minecraftAccessToken;
        std::string minecraftUuid;
        std::string minecraftUsername;
        std::string msRefreshToken; // stored so the user isn't asked to log in every launch
        bool ownsGame = false;
    };

    // Called with the code the user must enter, and the URL to visit (e.g. microsoft.com/link).
    using DeviceCodePrompt = std::function<void(const std::string& userCode, const std::string& verificationUrl)>;

    explicit MicrosoftAuth(std::string azureClientId);

    // Full interactive login. Blocks (intended to be run on a worker thread) while
    // polling Microsoft for the user to complete the browser step.
    // Returns std::nullopt on failure/cancellation.
    std::optional<Session> loginInteractive(const DeviceCodePrompt& onCodeReady);

    // Attempts to re-authenticate silently using a previously stored MS refresh token.
    std::optional<Session> loginWithRefreshToken(const std::string& refreshToken);

    void cancel(); // call from another thread to abort an in-progress device code poll

private:
    std::string clientId_;
    bool cancelRequested_ = false;

    struct MsToken { std::string accessToken; std::string refreshToken; };

    std::optional<MsToken> deviceCodeFlow(const DeviceCodePrompt& onCodeReady);
    std::optional<MsToken> refreshMsToken(const std::string& refreshToken);
    std::optional<Session> completeXboxChain(const MsToken& msToken);
};
