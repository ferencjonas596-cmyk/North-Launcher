#pragma once

// ---------------------------------------------------------------------------
// YOU MUST SET THIS. Every legitimate third-party Minecraft launcher requires
// its own Azure AD "Application (client) ID" - Microsoft does not allow reuse
// of someone else's. It's free and takes about 2 minutes:
//
//   1. Go to https://portal.azure.com -> "App registrations" -> "New registration"
//   2. Name: anything (e.g. "North Launcher")
//   3. Supported account types: "Personal Microsoft accounts only"
//   4. Redirect URI: leave blank (not needed for the device code flow)
//   5. After creation, copy the "Application (client) ID" GUID shown on the
//      Overview page and paste it below.
//
// No client secret is required for the device-code flow used by this app.
// ---------------------------------------------------------------------------
inline constexpr const char* kAzureClientId = "YOUR_AZURE_CLIENT_ID_HERE";
