#include "Downloader.h"
#include "../Utils/Http.h"
#include "../Utils/Paths.h"
#include <zip.h>
#include <filesystem>
#include <fstream>

using json = nlohmann::json;
namespace fs = std::filesystem;

namespace {

std::string currentOsName() {
#if defined(_WIN32)
    return "windows";
#elif defined(__APPLE__)
    return "osx";
#else
    return "linux";
#endif
}

void extractZip(const std::string& zipPath, const std::string& destDir,
                 const std::vector<std::string>& excludePrefixes) {
    int err = 0;
    zip_t* archive = zip_open(zipPath.c_str(), ZIP_RDONLY, &err);
    if (!archive) return;

    zip_int64_t numEntries = zip_get_num_entries(archive, 0);
    for (zip_int64_t i = 0; i < numEntries; ++i) {
        const char* name = zip_get_name(archive, i, 0);
        if (!name) continue;
        std::string entryName(name);

        bool excluded = false;
        for (const auto& prefix : excludePrefixes) {
            if (entryName.rfind(prefix, 0) == 0) { excluded = true; break; }
        }
        if (excluded || entryName.empty() || entryName.back() == '/') continue;

        zip_file_t* zf = zip_fopen_index(archive, i, 0);
        if (!zf) continue;

        fs::path outPath = fs::path(destDir) / entryName;
        fs::create_directories(outPath.parent_path());

        std::ofstream out(outPath, std::ios::binary);
        char buf[8192];
        zip_int64_t n;
        while ((n = zip_fread(zf, buf, sizeof(buf))) > 0) {
            out.write(buf, n);
        }
        zip_fclose(zf);
    }
    zip_close(archive);
}

} // namespace

bool Downloader::ruleAppliesToCurrentOs(const json& rules) const {
    // Mirrors the official launcher's rule evaluation: default allow, each rule
    // can allow/disallow based on OS name; last matching rule wins.
    bool allowed = true;
    for (const auto& rule : rules) {
        std::string action = rule.value("action", "allow");
        bool matches = true;
        if (rule.contains("os")) {
            std::string osName = rule["os"].value("name", "");
            if (!osName.empty() && osName != currentOsName()) matches = false;
        }
        if (matches) allowed = (action == "allow");
    }
    return allowed;
}

std::string Downloader::downloadClientJar(const json& versionJson, const std::string& versionId) {
    if (!versionJson.contains("downloads") || !versionJson["downloads"].contains("client")) return "";

    const auto& client = versionJson["downloads"]["client"];
    std::string url = client.value("url", "");
    std::string sha1 = client.value("sha1", "");
    if (url.empty()) return "";

    fs::path versionDir = fs::path(Paths::versionsDir()) / versionId;
    fs::create_directories(versionDir);
    fs::path jarPath = versionDir / (versionId + ".jar");

    if (!Http::downloadToFile(url, jarPath.string(), sha1)) return "";
    return jarPath.string();
}

std::vector<std::string> Downloader::downloadLibraries(const json& versionJson,
                                                         const std::string& versionId,
                                                         const ProgressCallback& onProgress) {
    std::vector<std::string> classpath;
    if (!versionJson.contains("libraries")) return classpath;

    std::string nativesOutDir = Paths::nativesDir(versionId);
    fs::create_directories(nativesOutDir);

    const auto& libraries = versionJson["libraries"];
    size_t total = libraries.size();
    size_t done = 0;

    for (const auto& lib : libraries) {
        if (lib.contains("rules") && !ruleAppliesToCurrentOs(lib["rules"])) {
            ++done;
            continue;
        }
        if (!lib.contains("downloads")) { ++done; continue; }

        const auto& downloads = lib["downloads"];

        // Regular library jar (goes on the classpath).
        if (downloads.contains("artifact")) {
            const auto& artifact = downloads["artifact"];
            std::string relPath = artifact.value("path", "");
            std::string url = artifact.value("url", "");
            std::string sha1 = artifact.value("sha1", "");
            if (!relPath.empty() && !url.empty()) {
                fs::path outPath = fs::path(Paths::librariesDir()) / relPath;
                fs::create_directories(outPath.parent_path());
                if (onProgress) onProgress({relPath, done, total});
                if (Http::downloadToFile(url, outPath.string(), sha1)) {
                    classpath.push_back(outPath.string());
                }
            }
        }

        // Native library archive for the current OS (extracted, not added to classpath).
        if (lib.contains("natives") && downloads.contains("classifiers")) {
            std::string osName = currentOsName();
            std::string key = lib["natives"].value(osName, "");
            if (!key.empty() && downloads["classifiers"].contains(key)) {
                const auto& nativeArtifact = downloads["classifiers"][key];
                std::string url = nativeArtifact.value("url", "");
                std::string sha1 = nativeArtifact.value("sha1", "");
                if (!url.empty()) {
                    fs::path tmpZip = fs::path(nativesOutDir) / "_tmp_native.zip";
                    if (Http::downloadToFile(url, tmpZip.string(), sha1)) {
                        extractZip(tmpZip.string(), nativesOutDir, {"META-INF/"});
                        fs::remove(tmpZip);
                    }
                }
            }
        }

        ++done;
    }

    return classpath;
}

bool Downloader::downloadAssets(const json& versionJson, const ProgressCallback& onProgress) {
    if (!versionJson.contains("assetIndex")) return false;

    const auto& assetIndexMeta = versionJson["assetIndex"];
    std::string indexUrl = assetIndexMeta.value("url", "");
    std::string indexId = assetIndexMeta.value("id", "legacy");
    if (indexUrl.empty()) return false;

    fs::path indexPath = fs::path(Paths::assetsDir()) / "indexes" / (indexId + ".json");
    fs::create_directories(indexPath.parent_path());

    if (!Http::downloadToFile(indexUrl, indexPath.string(), assetIndexMeta.value("sha1", ""))) {
        return false;
    }

    std::ifstream in(indexPath);
    json index = json::parse(in, nullptr, false);
    if (index.is_discarded() || !index.contains("objects")) return false;

    const auto& objects = index["objects"];
    size_t total = objects.size();
    size_t done = 0;

    for (auto& [name, obj] : objects.items()) {
        std::string hash = obj.value("hash", "");
        if (hash.empty()) { ++done; continue; }
        std::string prefix = hash.substr(0, 2);

        fs::path outPath = fs::path(Paths::assetsDir()) / "objects" / prefix / hash;
        fs::create_directories(outPath.parent_path());

        if (onProgress) onProgress({name, done, total});

        if (!fs::exists(outPath)) {
            std::string url = "https://resources.download.minecraft.net/" + prefix + "/" + hash;
            Http::downloadToFile(url, outPath.string(), hash);
        }
        ++done;
    }

    return true;
}
