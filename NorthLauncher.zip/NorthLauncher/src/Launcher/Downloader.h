#pragma once
#include <string>
#include <vector>
#include <functional>
#include <nlohmann/json.hpp>

// Downloads everything a given version JSON references: the client jar, the
// libraries it depends on (applying the same OS/arch "rules" logic the official
// launcher uses), native library archives, and the asset objects (textures, sounds).
class Downloader {
public:
    struct ProgressInfo {
        std::string currentFile;
        size_t filesDone = 0;
        size_t filesTotal = 0;
    };
    using ProgressCallback = std::function<void(const ProgressInfo&)>;

    // Downloads the client .jar for this version. Returns the path it was saved to, or "" on failure.
    std::string downloadClientJar(const nlohmann::json& versionJson, const std::string& versionId);

    // Downloads every required library (jars + natives), extracting native archives
    // into the version's natives/ directory. Returns the classpath list of jar paths.
    std::vector<std::string> downloadLibraries(const nlohmann::json& versionJson,
                                                const std::string& versionId,
                                                const ProgressCallback& onProgress = nullptr);

    // Downloads the asset index + every referenced asset object.
    bool downloadAssets(const nlohmann::json& versionJson, const ProgressCallback& onProgress = nullptr);

private:
    bool ruleAppliesToCurrentOs(const nlohmann::json& rules) const;
};
