#include "GameLauncher.h"
#include <sstream>

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#include <sys/wait.h>
#endif

using json = nlohmann::json;

namespace {
#ifdef _WIN32
constexpr char kPathSep = ';';
#else
constexpr char kPathSep = ':';
#endif

std::string join(const std::vector<std::string>& parts, char sep) {
    std::ostringstream oss;
    for (size_t i = 0; i < parts.size(); ++i) {
        if (i) oss << sep;
        oss << parts[i];
    }
    return oss.str();
}

void replaceAll(std::string& s, const std::string& from, const std::string& to) {
    if (from.empty()) return;
    size_t pos = 0;
    while ((pos = s.find(from, pos)) != std::string::npos) {
        s.replace(pos, from.length(), to);
        pos += to.length();
    }
}
}

std::string GameLauncher::substitutePlaceholders(const std::string& tmpl, const LaunchOptions& opts,
                                                  const std::string& classpathJoined) const {
    std::string s = tmpl;
    replaceAll(s, "${auth_player_name}", opts.playerName);
    replaceAll(s, "${version_name}", opts.versionId);
    replaceAll(s, "${game_directory}", opts.gameDirectory);
    replaceAll(s, "${assets_root}", opts.gameDirectory + "/assets");
    replaceAll(s, "${assets_index_name}", opts.versionId);
    replaceAll(s, "${auth_uuid}", opts.playerUuid);
    replaceAll(s, "${auth_access_token}", opts.accessToken);
    replaceAll(s, "${user_type}", "msa");
    replaceAll(s, "${version_type}", "release");
    replaceAll(s, "${resolution_width}", opts.windowWidth);
    replaceAll(s, "${resolution_height}", opts.windowHeight);
    replaceAll(s, "${classpath}", classpathJoined);
    replaceAll(s, "${natives_directory}", opts.gameDirectory + "/natives");
    replaceAll(s, "${launcher_name}", "NorthLauncher");
    replaceAll(s, "${launcher_version}", "1.0.0");
    return s;
}

std::vector<std::string> GameLauncher::buildArguments(const json& versionJson, const LaunchOptions& opts) const {
    std::vector<std::string> args;

    std::vector<std::string> fullClasspath = opts.classpath;
    if (!opts.clientJarPath.empty()) fullClasspath.push_back(opts.clientJarPath);
    std::string cp = join(fullClasspath, kPathSep);

    // JVM memory + basic flags (always present regardless of version format).
    args.push_back("-Xmx" + std::to_string(opts.maxMemoryMb) + "M");
    args.push_back("-Xms" + std::to_string(opts.minMemoryMb) + "M");
    args.push_back("-Djava.library.path=" + opts.gameDirectory + "/natives");
    args.push_back("-cp");
    args.push_back(cp);

    // Modern (1.13+) versions describe arguments as structured "arguments.jvm" / "arguments.game"
    // lists (with conditional {"rules": ...} entries we simplify by skipping); older versions use
    // a flat "minecraftArguments" string. Handle both, same as the official launcher.
    if (versionJson.contains("arguments")) {
        const auto& arguments = versionJson["arguments"];

        if (arguments.contains("jvm")) {
            for (const auto& a : arguments["jvm"]) {
                if (a.is_string()) args.push_back(substitutePlaceholders(a.get<std::string>(), opts, cp));
                // Rule-gated JVM args (e.g. macOS-only flags) are skipped here for simplicity;
                // extend ruleAppliesToCurrentOs-style logic from Downloader if you need them.
            }
        }

        args.push_back(versionJson.value("mainClass", "net.minecraft.client.main.Main"));

        if (arguments.contains("game")) {
            for (const auto& a : arguments["game"]) {
                if (a.is_string()) args.push_back(substitutePlaceholders(a.get<std::string>(), opts, cp));
            }
        }
    } else if (versionJson.contains("minecraftArguments")) {
        args.push_back(versionJson.value("mainClass", "net.minecraft.client.main.Main"));
        std::string legacy = substitutePlaceholders(versionJson["minecraftArguments"].get<std::string>(), opts, cp);
        std::istringstream iss(legacy);
        std::string token;
        while (iss >> token) args.push_back(token);
    } else {
        args.push_back(versionJson.value("mainClass", "net.minecraft.client.main.Main"));
    }

    return args;
}

unsigned long GameLauncher::launch(const LaunchOptions& opts, const std::vector<std::string>& arguments) const {
#ifdef _WIN32
    std::ostringstream cmd;
    cmd << "\"" << opts.javaPath << "\"";
    for (const auto& a : arguments) {
        cmd << " \"" << a << "\"";
    }
    std::string cmdStr = cmd.str();

    STARTUPINFOA si{};
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};

    std::vector<char> cmdBuf(cmdStr.begin(), cmdStr.end());
    cmdBuf.push_back('\0');

    BOOL ok = CreateProcessA(
        nullptr, cmdBuf.data(), nullptr, nullptr, FALSE,
        CREATE_NEW_CONSOLE, nullptr, opts.gameDirectory.c_str(), &si, &pi);

    if (!ok) return 0;

    CloseHandle(pi.hThread);
    unsigned long pid = pi.dwProcessId;
    CloseHandle(pi.hProcess);
    return pid;
#else
    // Dev-platform fallback (Linux/macOS) so the same code can be built/tested off-Windows.
    pid_t pid = fork();
    if (pid == 0) {
        std::vector<char*> argv;
        argv.push_back(const_cast<char*>(opts.javaPath.c_str()));
        for (const auto& a : arguments) argv.push_back(const_cast<char*>(a.c_str()));
        argv.push_back(nullptr);
        chdir(opts.gameDirectory.c_str());
        execvp(opts.javaPath.c_str(), argv.data());
        _exit(127);
    }
    return static_cast<unsigned long>(pid);
#endif
}
