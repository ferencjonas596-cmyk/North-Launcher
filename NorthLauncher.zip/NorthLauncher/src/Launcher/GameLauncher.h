#pragma once
#include <string>
#include <vector>
#include <nlohmann/json.hpp>

// Assembles the full `java ...` command line the same way the official launcher does
// (substituting the ${...} placeholders in the version JSON's argument templates)
// and starts the game as a child process.
class GameLauncher {
public:
    struct LaunchOptions {
        std::string javaPath = "java";       // path to a Java runtime matching the version's requirement
        std::string versionId;
        std::string gameDirectory;           // where saves/, resourcepacks/, etc. live
        std::vector<std::string> classpath;  // from Downloader::downloadLibraries + the client jar
        std::string clientJarPath;

        // Auth (from MicrosoftAuth::Session)
        std::string playerName;
        std::string playerUuid;
        std::string accessToken;

        int maxMemoryMb = 4096;
        int minMemoryMb = 1024;
        std::string windowWidth = "1280";
        std::string windowHeight = "720";
    };

    // Builds the argument vector (does not include the java executable itself as argv[0]).
    std::vector<std::string> buildArguments(const nlohmann::json& versionJson, const LaunchOptions& opts) const;

    // Launches the process. Returns the child's process id, or 0 on failure.
    // On Windows this uses CreateProcess; stdout/stderr can optionally be piped for a log view.
    unsigned long launch(const LaunchOptions& opts, const std::vector<std::string>& arguments) const;

private:
    std::string substitutePlaceholders(const std::string& templateStr, const LaunchOptions& opts,
                                        const std::string& classpathJoined) const;
};
