#include "VersionManager.h"
#include "../Utils/Http.h"
#include "../Utils/Paths.h"
#include <filesystem>
#include <fstream>

using json = nlohmann::json;
namespace fs = std::filesystem;

namespace {
constexpr const char* kManifestUrl = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";
}

std::vector<VersionManager::VersionEntry> VersionManager::fetchVersionList() {
    std::vector<VersionEntry> result;

    auto resp = Http::get(kManifestUrl);
    if (!resp.ok()) return result;

    json manifest = json::parse(resp.body, nullptr, false);
    if (manifest.is_discarded() || !manifest.contains("versions")) return result;

    for (const auto& v : manifest["versions"]) {
        VersionEntry e;
        e.id = v.value("id", "");
        e.type = v.value("type", "");
        e.url = v.value("url", "");
        e.releaseTime = v.value("releaseTime", "");
        if (!e.id.empty()) result.push_back(e);
    }
    return result;
}

json VersionManager::fetchVersionDetails(const VersionEntry& entry) {
    fs::path versionDir = fs::path(Paths::versionsDir()) / entry.id;
    fs::create_directories(versionDir);
    fs::path cacheFile = versionDir / (entry.id + ".json");

    // Use the cached copy if we already have it - version JSONs are immutable per-id.
    if (fs::exists(cacheFile)) {
        std::ifstream in(cacheFile);
        json cached = json::parse(in, nullptr, false);
        if (!cached.is_discarded()) return resolveInheritance(cached);
    }

    auto resp = Http::get(entry.url);
    if (!resp.ok()) return json{};

    json details = json::parse(resp.body, nullptr, false);
    if (details.is_discarded()) return json{};

    std::ofstream out(cacheFile);
    out << details.dump(2);

    return resolveInheritance(details);
}

json VersionManager::resolveInheritance(json versionJson) {
    // Some profiles (notably modloaders like Forge/Fabric, when you add support for them
    // later) declare "inheritsFrom": "<vanilla id>" and only override a few fields.
    if (!versionJson.contains("inheritsFrom")) return versionJson;

    std::string parentId = versionJson["inheritsFrom"];
    fs::path parentFile = fs::path(Paths::versionsDir()) / parentId / (parentId + ".json");
    if (!fs::exists(parentFile)) return versionJson; // caller is responsible for fetching parent first

    std::ifstream in(parentFile);
    json parent = json::parse(in, nullptr, false);
    if (parent.is_discarded()) return versionJson;

    // Merge: child libraries/arguments are appended to the parent's; scalar fields
    // (mainClass, etc.) from the child take precedence.
    json merged = parent;
    for (auto& [key, value] : versionJson.items()) {
        if (key == "libraries" && merged.contains("libraries")) {
            for (auto& lib : value) merged["libraries"].push_back(lib);
        } else if (key == "arguments" && merged.contains("arguments")) {
            for (auto& [argKey, argVal] : value.items()) {
                if (merged["arguments"].contains(argKey)) {
                    for (auto& a : argVal) merged["arguments"][argKey].push_back(a);
                } else {
                    merged["arguments"][argKey] = argVal;
                }
            }
        } else {
            merged[key] = value;
        }
    }
    return merged;
}
