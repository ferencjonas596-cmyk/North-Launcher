#pragma once
#include <string>
#include <vector>
#include <nlohmann/json.hpp>

// Talks to Mojang's public, unauthenticated version manifest API to list
// available Minecraft versions and fetch full metadata for a chosen one.
//   https://piston-meta.mojang.com/mc/game/version_manifest_v2.json
class VersionManager {
public:
    struct VersionEntry {
        std::string id;       // e.g. "1.21.4"
        std::string type;     // "release" | "snapshot" | "old_beta" | "old_alpha"
        std::string url;      // link to this version's full metadata json
        std::string releaseTime;
    };

    // Fetches and returns the list of all versions (newest first), as published by Mojang.
    std::vector<VersionEntry> fetchVersionList();

    // Fetches the full version JSON (libraries, download URLs, main class, java version, etc).
    // Caches it to <root>/versions/<id>/<id>.json so repeated launches don't re-fetch.
    nlohmann::json fetchVersionDetails(const VersionEntry& entry);

    // If a version inherits from another (e.g. most modded/forge profiles), merges parent fields in.
    nlohmann::json resolveInheritance(nlohmann::json versionJson);
};
