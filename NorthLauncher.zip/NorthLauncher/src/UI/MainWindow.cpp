#include "MainWindow.h"
#include "../Config.h"
#include "../Utils/Paths.h"
#include "../Launcher/Downloader.h"
#include "../Launcher/GameLauncher.h"
#include "../Utils/Http.h"

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QInputDialog>
#include <QDesktopServices>
#include <QUrl>
#include <QApplication>
#include <QClipboard>
#include <QtConcurrent/QtConcurrent>
#include <QFuture>
#include <QFutureWatcher>
#include <fstream>

using json = nlohmann::json;

MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent), auth_(kAzureClientId) {
    setWindowTitle("North Launcher");
    resize(560, 480);

    auto* central = new QWidget(this);
    auto* layout = new QVBoxLayout(central);

    auto* topRow = new QHBoxLayout();
    accountLabel_ = new QLabel("Not logged in", central);
    loginButton_ = new QPushButton("Log in with Microsoft", central);
    topRow->addWidget(accountLabel_, 1);
    topRow->addWidget(loginButton_);
    layout->addLayout(topRow);

    auto* versionRow = new QHBoxLayout();
    versionRow->addWidget(new QLabel("Version:", central));
    versionCombo_ = new QComboBox(central);
    versionCombo_->addItem("Loading versions...");
    versionRow->addWidget(versionCombo_, 1);
    layout->addLayout(versionRow);

    playButton_ = new QPushButton("Play", central);
    playButton_->setEnabled(false);
    playButton_->setMinimumHeight(40);
    layout->addWidget(playButton_);

    progressBar_ = new QProgressBar(central);
    progressBar_->setRange(0, 100);
    progressBar_->setValue(0);
    layout->addWidget(progressBar_);

    logView_ = new QPlainTextEdit(central);
    logView_->setReadOnly(true);
    layout->addWidget(logView_, 1);

    setCentralWidget(central);

    connect(loginButton_, &QPushButton::clicked, this, &MainWindow::onLoginClicked);
    connect(playButton_, &QPushButton::clicked, this, &MainWindow::onPlayClicked);

    Paths::ensureDirectories();
    Http::globalInit();

    loadVersionsAsync();
    tryAutoLogin();
}

void MainWindow::log(const QString& line) {
    logView_->appendPlainText(line);
}

void MainWindow::setUiBusy(bool busy) {
    loginButton_->setEnabled(!busy);
    playButton_->setEnabled(!busy && session_.has_value());
    versionCombo_->setEnabled(!busy);
}

void MainWindow::loadVersionsAsync() {
    auto* watcher = new QFutureWatcher<std::vector<VersionManager::VersionEntry>>(this);
    connect(watcher, &QFutureWatcher<std::vector<VersionManager::VersionEntry>>::finished, this, [this, watcher]() {
        versions_ = watcher->result();
        versionCombo_->clear();
        for (const auto& v : versions_) {
            if (v.type == "release") { // hide snapshots by default to keep the list manageable
                versionCombo_->addItem(QString::fromStdString(v.id));
            }
        }
        if (versionCombo_->count() == 0) log("Failed to load version list - check your internet connection.");
        watcher->deleteLater();
    });
    QFuture<std::vector<VersionManager::VersionEntry>> future = QtConcurrent::run([]() {
        VersionManager vm;
        return vm.fetchVersionList();
    });
    watcher->setFuture(future);
}

void MainWindow::tryAutoLogin() {
    std::ifstream in(Paths::authCacheFile());
    if (!in.good()) return;
    json cache = json::parse(in, nullptr, false);
    if (cache.is_discarded() || !cache.contains("refresh_token")) return;

    std::string refreshToken = cache["refresh_token"];
    setUiBusy(true);
    log("Attempting silent login with saved credentials...");

    auto* watcher = new QFutureWatcher<std::optional<MicrosoftAuth::Session>>(this);
    connect(watcher, &QFutureWatcher<std::optional<MicrosoftAuth::Session>>::finished, this, [this, watcher]() {
        auto result = watcher->result();
        if (result) {
            session_ = result;
            accountLabel_->setText(QString("Logged in as %1").arg(QString::fromStdString(result->minecraftUsername)));
            if (!result->ownsGame) {
                log("Warning: this account does not appear to own Minecraft: Java Edition.");
            }
            log("Silent login succeeded.");
        } else {
            log("Silent login failed - please log in manually.");
        }
        setUiBusy(false);
        watcher->deleteLater();
    });
    watcher->setFuture(QtConcurrent::run([this, refreshToken]() {
        return auth_.loginWithRefreshToken(refreshToken);
    }));
}

void MainWindow::onLoginClicked() {
    setUiBusy(true);
    log("Starting Microsoft login...");

    auto* watcher = new QFutureWatcher<std::optional<MicrosoftAuth::Session>>(this);
    connect(watcher, &QFutureWatcher<std::optional<MicrosoftAuth::Session>>::finished, this, [this, watcher]() {
        auto result = watcher->result();
        if (result) {
            session_ = result;
            accountLabel_->setText(QString("Logged in as %1").arg(QString::fromStdString(result->minecraftUsername)));
            if (!result->ownsGame) {
                QMessageBox::warning(this, "No Minecraft license found",
                    "This Microsoft account doesn't appear to own Minecraft: Java Edition. "
                    "You can still browse, but launching will fail.");
            }
            // Persist only the MS refresh token (not the Minecraft access token, which is short-lived).
            json cache = {{"refresh_token", result->msRefreshToken}};
            std::ofstream out(Paths::authCacheFile());
            out << cache.dump(2);

            log("Login successful.");
        } else {
            log("Login failed or was cancelled.");
            QMessageBox::critical(this, "Login failed",
                "Could not complete Microsoft sign-in. Make sure you entered the code correctly "
                "and that this account owns Minecraft: Java Edition.");
        }
        setUiBusy(false);
        watcher->deleteLater();
    });

    watcher->setFuture(QtConcurrent::run([this]() {
        return auth_.loginInteractive([this](const std::string& code, const std::string& url) {
            // Runs on the worker thread - marshal the dialog back to the UI thread.
            QMetaObject::invokeMethod(this, [this, code, url]() {
                QApplication::clipboard()->setText(QString::fromStdString(code));
                log(QString("Go to %1 and enter code: %2 (copied to clipboard)")
                        .arg(QString::fromStdString(url), QString::fromStdString(code)));
                QDesktopServices::openUrl(QUrl(QString::fromStdString(url)));
            }, Qt::QueuedConnection);
        });
    }));
}

void MainWindow::onPlayClicked() {
    if (!session_) {
        QMessageBox::information(this, "Not logged in", "Please log in with Microsoft first.");
        return;
    }
    if (versionCombo_->currentIndex() < 0) return;

    std::string versionId = versionCombo_->currentText().toStdString();
    VersionManager::VersionEntry entry;
    for (const auto& v : versions_) {
        if (v.id == versionId) { entry = v; break; }
    }
    if (entry.id.empty()) return;

    setUiBusy(true);
    progressBar_->setValue(0);
    log("Preparing to launch " + QString::fromStdString(versionId) + "...");

    auto* watcher = new QFutureWatcher<bool>(this);
    connect(watcher, &QFutureWatcher<bool>::finished, this, [this, watcher]() {
        bool ok = watcher->result();
        log(ok ? "Game launched." : "Launch failed - see log above.");
        setUiBusy(true); // keep disabled briefly; re-enable below
        setUiBusy(false);
        watcher->deleteLater();
    });

    watcher->setFuture(QtConcurrent::run([this, entry]() {
        VersionManager vm;
        json versionJson = vm.fetchVersionDetails(entry);
        if (versionJson.empty()) {
            QMetaObject::invokeMethod(this, [this]() { log("Failed to fetch version metadata."); });
            return false;
        }

        Downloader dl;
        QMetaObject::invokeMethod(this, [this]() { log("Downloading client jar..."); });
        std::string clientJar = dl.downloadClientJar(versionJson, entry.id);
        if (clientJar.empty()) {
            QMetaObject::invokeMethod(this, [this]() { log("Failed to download client jar."); });
            return false;
        }

        QMetaObject::invokeMethod(this, [this]() { log("Downloading libraries..."); });
        auto classpath = dl.downloadLibraries(versionJson, entry.id, [this](const Downloader::ProgressInfo& p) {
            if (p.filesTotal == 0) return;
            int pct = static_cast<int>((p.filesDone * 100) / p.filesTotal);
            QMetaObject::invokeMethod(this, [this, pct]() { progressBar_->setValue(pct); });
        });

        QMetaObject::invokeMethod(this, [this]() { log("Downloading assets (this can take a while the first time)..."); });
        dl.downloadAssets(versionJson, [this](const Downloader::ProgressInfo& p) {
            if (p.filesTotal == 0) return;
            int pct = static_cast<int>((p.filesDone * 100) / p.filesTotal);
            QMetaObject::invokeMethod(this, [this, pct]() { progressBar_->setValue(pct); });
        });

        GameLauncher::LaunchOptions opts;
        opts.versionId = entry.id;
        opts.gameDirectory = Paths::rootDir();
        opts.classpath = classpath;
        opts.clientJarPath = clientJar;
        opts.playerName = session_->minecraftUsername;
        opts.playerUuid = session_->minecraftUuid;
        opts.accessToken = session_->minecraftAccessToken;
        opts.javaPath = "java"; // resolved from PATH; point this at a bundled JRE if you embed one

        GameLauncher launcher;
        auto args = launcher.buildArguments(versionJson, opts);
        unsigned long pid = launcher.launch(opts, args);

        return pid != 0;
    }));
}
