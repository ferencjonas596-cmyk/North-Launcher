#pragma once
#include <QMainWindow>
#include <QComboBox>
#include <QPushButton>
#include <QLabel>
#include <QProgressBar>
#include <QPlainTextEdit>
#include <optional>
#include "../Auth/MicrosoftAuth.h"
#include "../Launcher/VersionManager.h"

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget* parent = nullptr);

private slots:
    void onLoginClicked();
    void onPlayClicked();
    void onVersionsLoaded();

private:
    void log(const QString& line);
    void setUiBusy(bool busy);
    void loadVersionsAsync();
    void tryAutoLogin();

    QLabel* accountLabel_;
    QPushButton* loginButton_;
    QComboBox* versionCombo_;
    QPushButton* playButton_;
    QProgressBar* progressBar_;
    QPlainTextEdit* logView_;

    MicrosoftAuth auth_;
    std::optional<MicrosoftAuth::Session> session_;
    std::vector<VersionManager::VersionEntry> versions_;
};
