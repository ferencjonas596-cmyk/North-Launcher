#include "Http.h"
#include <curl/curl.h>
#include <openssl/sha.h>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <cstdio>

namespace {

size_t writeToString(char* ptr, size_t size, size_t nmemb, void* userdata) {
    auto* out = static_cast<std::string*>(userdata);
    out->append(ptr, size * nmemb);
    return size * nmemb;
}

size_t writeToFile(char* ptr, size_t size, size_t nmemb, void* userdata) {
    auto* f = static_cast<std::ofstream*>(userdata);
    f->write(ptr, static_cast<std::streamsize>(size * nmemb));
    return size * nmemb;
}

struct ProgressContext {
    const Http::ProgressCallback* cb;
};

int progressTrampoline(void* clientp, curl_off_t dltotal, curl_off_t dlnow,
                        curl_off_t /*ultotal*/, curl_off_t /*ulnow*/) {
    auto* ctx = static_cast<ProgressContext*>(clientp);
    if (ctx && ctx->cb && *ctx->cb) {
        bool keepGoing = (*ctx->cb)(dlnow, dltotal);
        return keepGoing ? 0 : 1; // non-zero aborts the transfer
    }
    return 0;
}

curl_slist* buildHeaderList(const std::vector<std::string>& headers) {
    curl_slist* list = nullptr;
    for (const auto& h : headers) {
        list = curl_slist_append(list, h.c_str());
    }
    return list;
}

std::string sha1Hex(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return "";

    SHA_CTX ctx;
    SHA1_Init(&ctx);
    char buf[8192];
    while (f.read(buf, sizeof(buf)) || f.gcount() > 0) {
        SHA1_Update(&ctx, buf, static_cast<size_t>(f.gcount()));
    }
    unsigned char digest[SHA_DIGEST_LENGTH];
    SHA1_Final(digest, &ctx);

    std::ostringstream oss;
    for (unsigned char b : digest) {
        oss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(b);
    }
    return oss.str();
}

} // namespace

namespace Http {

void globalInit() { curl_global_init(CURL_GLOBAL_DEFAULT); }
void globalCleanup() { curl_global_cleanup(); }

Response get(const std::string& url, const std::vector<std::string>& headers) {
    Response resp;
    CURL* curl = curl_easy_init();
    if (!curl) return resp;

    curl_slist* headerList = buildHeaderList(headers);

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headerList);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeToString);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &resp.body);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 30L);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "NorthLauncher/1.0");

    curl_easy_perform(curl);
    long status = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status);
    resp.status = status;

    curl_slist_free_all(headerList);
    curl_easy_cleanup(curl);
    return resp;
}

Response post(const std::string& url, const std::string& body, const std::vector<std::string>& headers) {
    Response resp;
    CURL* curl = curl_easy_init();
    if (!curl) return resp;

    curl_slist* headerList = buildHeaderList(headers);

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headerList);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, body.c_str());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, static_cast<long>(body.size()));
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeToString);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &resp.body);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 30L);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "NorthLauncher/1.0");

    curl_easy_perform(curl);
    long status = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status);
    resp.status = status;

    curl_slist_free_all(headerList);
    curl_easy_cleanup(curl);
    return resp;
}

bool downloadToFile(const std::string& url, const std::string& destPath,
                     const std::string& expectedSha1,
                     const ProgressCallback& onProgress) {
    // Skip re-downloading if the file already exists and matches the expected hash.
    if (!expectedSha1.empty()) {
        std::ifstream existing(destPath, std::ios::binary);
        if (existing.good()) {
            existing.close();
            if (sha1Hex(destPath) == expectedSha1) {
                return true;
            }
        }
    }

    std::ofstream out(destPath, std::ios::binary | std::ios::trunc);
    if (!out) return false;

    CURL* curl = curl_easy_init();
    if (!curl) return false;

    ProgressContext ctx{&onProgress};

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeToFile);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &out);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 300L);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "NorthLauncher/1.0");

    if (onProgress) {
        curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0L);
        curl_easy_setopt(curl, CURLOPT_XFERINFOFUNCTION, progressTrampoline);
        curl_easy_setopt(curl, CURLOPT_XFERINFODATA, &ctx);
    }

    CURLcode res = curl_easy_perform(curl);
    long status = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status);
    curl_easy_cleanup(curl);
    out.close();

    if (res != CURLE_OK || status < 200 || status >= 300) {
        std::remove(destPath.c_str());
        return false;
    }

    if (!expectedSha1.empty() && sha1Hex(destPath) != expectedSha1) {
        std::remove(destPath.c_str());
        return false;
    }

    return true;
}

} // namespace Http
