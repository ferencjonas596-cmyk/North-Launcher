#pragma once
#include <string>
#include <vector>
#include <functional>
#include <curl/curl.h>

// Minimal synchronous HTTP client wrapper around libcurl.
// Every network call in the launcher (auth, manifests, downloads) goes through this.
namespace Http {

struct Response {
    long status = 0;
    std::string body;
    bool ok() const { return status >= 200 && status < 300; }
};

// Progress callback: (bytesDownloaded, totalBytes) -> return false to abort.
using ProgressCallback = std::function<bool(curl_off_t, curl_off_t)>;

// Simple GET request.
Response get(const std::string& url, const std::vector<std::string>& headers = {});

// POST with a raw body (caller sets Content-Type via headers, e.g. "application/x-www-form-urlencoded" or "application/json").
Response post(const std::string& url, const std::string& body, const std::vector<std::string>& headers = {});

// Download a URL directly to a file on disk, optionally reporting progress and verifying a sha1 hash.
// Returns true on success (and matching hash, if expectedSha1 is non-empty).
bool downloadToFile(const std::string& url, const std::string& destPath,
                     const std::string& expectedSha1 = "",
                     const ProgressCallback& onProgress = nullptr);

// One-time global init/cleanup - call once at program start/end.
void globalInit();
void globalCleanup();

} // namespace Http
