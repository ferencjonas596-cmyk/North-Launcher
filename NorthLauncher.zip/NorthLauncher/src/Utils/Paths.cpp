#include "Paths.h"
#include <filesystem>
#include <cstdlib>

namespace fs = std::filesystem;

namespace {
std::string envVar(const char* name) {
#ifdef _WIN32
    char* buf = nullptr;
    size_t len = 0;
    std::string result;
    if (_dupenv_s(&buf, &len, name) == 0 && buf) {
        result = buf;
        free(buf);
    }
    return result;
#else
    const char* v = std::getenv(name);
    return v ? std::string(v) : std::string();
#endif
}
}

namespace Paths {

std::string rootDir() {
#ifdef _WIN32
    std::string appData = envVar("APPDATA");
    fs::path p = appData.empty() ? fs::path(".") : fs::path(appData);
    p /= ".mclauncher";
#else
    std::string home = envVar("HOME");
    fs::path p = home.empty() ? fs::path(".") : fs::path(home);
    p /= ".mclauncher";
#endif
    return p.string();
}

std::string versionsDir()  { return (fs::path(rootDir()) / "versions").string(); }
std::string librariesDir() { return (fs::path(rootDir()) / "libraries").string(); }
std::string assetsDir()    { return (fs::path(rootDir()) / "assets").string(); }

std::string nativesDir(const std::string& versionId) {
    return (fs::path(versionsDir()) / versionId / "natives").string();
}

std::string authCacheFile() {
    return (fs::path(rootDir()) / "authcache.json").string();
}

void ensureDirectories() {
    fs::create_directories(rootDir());
    fs::create_directories(versionsDir());
    fs::create_directories(librariesDir());
    fs::create_directories(assetsDir());
    fs::create_directories(fs::path(assetsDir()) / "objects");
    fs::create_directories(fs::path(assetsDir()) / "indexes");
}

} // namespace Paths
