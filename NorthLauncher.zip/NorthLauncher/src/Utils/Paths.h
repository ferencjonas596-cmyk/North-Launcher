#pragma once
#include <string>

// Resolves and creates the launcher's working directories:
//   %APPDATA%\.mclauncher\          (Windows)
//   ~/.mclauncher/                  (macOS/Linux, for cross-platform dev builds)
namespace Paths {

std::string rootDir();          // base data directory
std::string versionsDir();      // <root>/versions
std::string librariesDir();     // <root>/libraries
std::string assetsDir();        // <root>/assets
std::string nativesDir(const std::string& versionId); // <root>/versions/<id>/natives
std::string authCacheFile();    // <root>/authcache.json (stores refresh token only)

void ensureDirectories();       // creates all of the above if missing

} // namespace Paths
