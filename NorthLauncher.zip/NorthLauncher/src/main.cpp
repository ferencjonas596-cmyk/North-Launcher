#include <QApplication>
#include "UI/MainWindow.h"
#include "Utils/Http.h"

int main(int argc, char* argv[]) {
    QApplication app(argc, argv);
    QApplication::setApplicationName("NorthLauncher");
    QApplication::setOrganizationName("MyLauncher");

    MainWindow window;
    window.show();

    int result = app.exec();
    Http::globalCleanup();
    return result;
}
